package com.example.chatwise

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ImageListActivity : AppCompatActivity() {

    private lateinit var imageAdapter: ImageAdapter
    private lateinit var imageViewModel: ImageViewModel

    private lateinit var imageRecyclerView: RecyclerView // Add this line

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image_list)

        imageRecyclerView = findViewById(R.id.imageRecyclerView) // Add this line

        imageAdapter = ImageAdapter()

        imageRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@ImageListActivity)
            adapter = imageAdapter
        }

        imageViewModel = ViewModelProvider(this)[ImageViewModel::class.java]
        imageViewModel.getImages().observe(this) { images ->
            imageAdapter.setImages(images)
        }

        imageViewModel.fetchImages()
    }
}
