package com.example.chatwise

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class ImageViewModel : ViewModel() {

    private val images: MutableLiveData<List<Image>> = MutableLiveData()

    fun getImages(): LiveData<List<Image>> = images

    fun fetchImages() {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://jsonplaceholder.typicode.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service = retrofit.create(ApiService::class.java)
        val call = service.getImages()

        call.enqueue(object : Callback<List<Image>> {
            override fun onResponse(call: Call<List<Image>>, response: Response<List<Image>>) {
                if (response.isSuccessful) {
                    val fetchedImages = response.body()
                    images.value = fetchedImages
                }
            }

            override fun onFailure(call: Call<List<Image>>, t: Throwable) {
                // Handle API request failure
            }
        })
    }
}