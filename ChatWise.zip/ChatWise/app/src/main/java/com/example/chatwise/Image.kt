package com.example.chatwise

data class Image(
    val id: Int,
    val title: String,
    val url: String,
    val thumbnailUrl: String
)